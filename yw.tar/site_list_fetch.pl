#!/usr/bin/perl
use LWP::UserAgent;
$|=1;
my $ua = new LWP::UserAgent;
my @urls;
#Crunchbase :p
$cb=1;
$tn=1;
$dw = 1;
$ap = 1;
open (OUT12, ">foomo");
$ua->agent('Mozilla/5.0');

sub hlurl {
  my $url = shift @_;
  chomp ($url);
  $url =~ s/^http:\/\/(|www\.|www2\.)//;
  #print "url $url\n";
  print OUT12 "$url\n";
  push @urls,$url;
}

if ($cb) {
$abc = 1;
for ($char = 'a'; $char-2 < 'z' && $abc ==1 ; ++$char) {
  if ($char > 'a') {
    sleep 10;
  }
  if ($char > 'z')  {
    $char = "other";
    $abc=0;
  }
  print "****CHAR $char sofar $urls\n";
  my $res = $ua->get("http://www.crunchbase.com/companies?c=$char");
  my $rt1 = $res->decoded_content;
  while ($rt1 =~ s/\"\/company\/(.*?)\"//) {
     #print "next $1\n";
     my $comp = $1;
     my $res2 = $ua->get("http://www.crunchbase.com/company/$comp");
     my $rt2 = $res2->decoded_content;
     if ($rt2 =~ /Website\<\/td\>\<td\s*class\=\"td\_right\"\>\<a\s*href\=\"http:\/\/(|www\.)(.*?)\"/) {
       #print "url $2\n";
       hlurl($2);
     }
  }
  if ($char > 'z') {
    break;
  }
}
}
if ($tn) {
#technorati
for (my $c = 1 ; $c < 11 ; ++$c) {
  print "tn page $c $urls so far\n";
  my $urlt = "http://technorati.com/pop/blogs\?type=faves\&page=$c";
  my $urlf = "http://technorati.com/pop/blogs\?type=links\&page=$c";
  my $res1 = $ua->get($urlt);
  $d = 1;
  while ($res1 =~ /The Technorati Monster escaped again/) {
    print "sleeping while the monster is about\n";
    $res1 = $ua->get($urlt);
    sleep ($d*30);
    $d++;
  }
  print "don't provoke the monster, lets have a nap\n";
  sleep ($d*30);
  my $res2 = $ua->get($urlf);
  while ($res2 =~ /The Technorati Monster escaped again/) {
    print "sleeping while the monster is about\n";
    $res2 = $ua->get($urlf);
    sleep ($d*30);
    $d++;
  }
  my $rt = $res1->decoded_content.$res2->decoded_content;
  print "got $rt\n";
  while ($rt =~ s/\"\/blogs\/(|www\.)(.*?)\"\s+//) {
    #print "url $2\n";
    #push @urls,$2;
    hlurl($2);
  }
#  exit(0);
}
}

if ($ap) {
  print "omnom\n";
  my $res = $ua->get("http://web2.ajaxprojects.com/");
  my $rt = $res->decoded_content;
  while ($rt =~ s/<img src=\"\/web2\/images\/mw.gif\"\/><\/td><td align="left"><a href="\/web2\/projects\/(.*?)\"//) {
     print "ap c:$1\n";
     my $cd = $1;
     my $res2 = $ua->get("http://web2.ajaxprojects.com/web2/projects/$cd/");
     my $c = 0;
     my $rt2 = $res2->decoded_content;
     while ($rt2 =~ />Details</) {
        while ($rt2 =~ s/\<a\s+href\=\"http:\/\/\s*(|www\.|www2\.)\s*(.*?)\"\s+target=\"\_blank\"\>Visit\s+Website\<\/a\>//) {
#           print "url $2\n";
#           push @urls, $2;
            hlurl($2);
        }
        $c++;
       my $res2 = $ua->get("http://web2.ajaxprojects.com/web2/projects/$cd/\?pageNumber=$c");
        print "c:$c\n";
        $rt2 = $res2->decoded_content;
     }

  }
}


if ($fsf) {
  
}
if ($dw) {
  print "omnomnom\n";
  my $res = $ua->get("http://distrowatch.com/search.php\?category=All&origin=All&basedon=All&desktop=All&architecture=All&status=All");
  my $rt = $res->decoded_content;
  #print "rt:$rt\n";
  while ($rt =~ s/<br><br><b>.*?\.\s+<a\s+href=\"(.*?)\"\>//) {
    print "d:$1\n";
    sleep 1;
    sleep 10*rand();
    my $res2 = $ua->get("http://distrowatch.com/table.php?distribution=$1");
    my $rt2 = $res2->decoded_content;
    while ($rt2 =~ s/<td class="Info"><a href="http:\/\/(|www\.)(.*?)\"//) {
      #print "urls: $2\n";
      #push @urls,$2;
      hlurl($2);
    }
  }
}

my @source_urls=("http://distrowatch.com/dwres.php?resource=links","http://www.debian.org");
push @urls , "firefox.org";
push @urls, "firefox.com";
push @urls, "opera.com";
push @urls , "holdenkarau.com";
#sprt
@sorted = sort @urls;
$prev = 'nonesuch';
@out = grep($_ ne $prev && (($prev) = $_), @sorted);
open (OUT , ">myurls");
foreach (@out) {
  print OUT "$_\n";
}
close (OUT);
