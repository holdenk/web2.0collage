
function start() {
  //Give our monster time to sleep
  sleep(1);
  myform.submit();
}
